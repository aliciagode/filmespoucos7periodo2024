<?php

require_once $_SERVER['DOCUMENT_ROOT']."/filmespoucos7periodo2024/modelo/vo/Usuario.php";
require_once $_SERVER['DOCUMENT_ROOT']."/filmespoucos7periodo2024/modelo/dao/UsuarioDAO.php";


$UsuarioQueQueroSalvar = new Usuario();
$UsuarioQueQueroSalvar  ->setNome($_POST['nome']);
$UsuarioQueQueroSalvar  ->setLogin($_POST['login']);
$UsuarioQueQueroSalvar  ->setEmail($_POST['email']);
$UsuarioQueQueroSalvar  ->setSenha($_POST['senha']);

print_r($UsuarioQueQueroSalvar);
if ($_POST['id']==0){
    UsuarioDAO::getInstance()->insert($UsuarioQueQueroSalvar);

}
else {
    $UsuarioQueQueroSalvar->setId($_POST['id']);
    UsuarioDAO::getInstance()->update($UsuarioQueQueroSalvar);
    
}
echo "<script> 
    alert ('Usuario salvo com sucesso!');
    window.location='../UsuarioAddEdit.php';

</script>";